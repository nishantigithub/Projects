from django.apps import AppConfig


class PlagiarismcheckerConfig(AppConfig):
    name = 'plagiarismchecker'
